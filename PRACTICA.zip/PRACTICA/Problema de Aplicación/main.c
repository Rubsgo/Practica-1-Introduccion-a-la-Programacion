#include <stdio.h>
#include <stdlib.h>
float const pi=3.1416, g=9.81, Da= 997, Dd=820;

int main(int argc, char *argv[])
{
  float v, d, h, p, densidad;
  char fluido;
  
  printf("Escriba el liquido que va a contener el pozo: \n A para Agua \n D para Diesel\n");
  scanf("%c",&fluido);
  
  printf("Ahora inrese el diametro:\n");
  scanf("%f",&d);
  
  densidad=(fluido=='A')?Da:Dd;
  
  printf("Escriba el valor de la presion hidrostatica:\n");
  scanf("%f",&p);
  
  h=p/(densidad*g);
  v=(pi*((d/2)*(d/2)))*h;
  
  printf("El volumen del pozo es:%f\n",v);
  
  system("PAUSE");	
  return 0;
}
