#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float pies,pulgadas,yardas,centimetros,metros;
  
  printf("Escriba el valor en pies que desea convertir:\n"); 
  scanf("%f",&pies);
   pulgadas=pies/12;
  printf("El valor en pulgadas es:%f\n",pulgadas);
   yardas=pies*3;
  printf("El valor en yardas es:%f\n",yardas);
   centimetros=(pies/12)*2.54;
  printf("El valor en centimetros es:%f\n",centimetros);
   metros=(pies/12)*2.54*100;
  printf("El valor en metros es:%f\n",metros);
   
  
  system("PAUSE");	
  return 0;
}
