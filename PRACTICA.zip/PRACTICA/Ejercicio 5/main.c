#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float grados;
  char letra;
  
  
  printf("Este programa le permitira hacer una transformacion de celcius a farenheit y viceversa\n\
  para ello especifique f para farenheit y c para celcius\n");
  printf("Grados:\t");
  scanf("%f %c",&grados, &letra);
  	
  grados=(letra=='f')?(grados=(5/9)*(grados-32)):(grados=grados);
  grados=(letra=='c')?(grados=(9/5)*(grados+32)):(grados=grados);
  
  letra=(letra=='c')?(letra='f'):(letra='c');
   
  
  printf("\n\tEsto equivale a:%.3f %c\n\n\n",grados,letra);
  
  system("PAUSE");	
  return 0;
}
