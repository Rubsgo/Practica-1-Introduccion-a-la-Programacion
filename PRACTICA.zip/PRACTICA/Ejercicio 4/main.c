#include <stdio.h>
#include <stdlib.h>



int main(int argc, char *argv[]) {
	int segundos_totales, segundos, minutos, horas;
	printf("ingrese el numero total de segundos:");
	scanf("%i",&segundos_totales);
	
	horas=(segundos_totales/3600>0)?(segundos_totales/3600):0;
	minutos=((segundos_totales%3600)/60 >0)?((segundos_totales%3600)/60):(0);
	segundos=(segundos_totales%60 == 0)?(0):(segundos_totales%60);
	
	printf("El numero total de segundos equivale a:\n");
	
	printf("Horas=%i\nMinutos=%i\nSegundos=%i\n",horas,minutos,segundos);
	
	
	
	system("pause");
	return 0;
}
