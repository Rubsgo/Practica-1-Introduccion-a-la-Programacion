#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int x,y,a,b,res;
    printf("Para obtener el valor de la operacion (x+y)*(x+y)*(a-b)\n");
    
    printf("Escriba el valor de x:\t"); 
    scanf("%d",&x);
    printf("Escriba el valor de y:\t");
    scanf("%d",&y);
    printf("Escriba el valor de a:\t");
    scanf("%d",&a);
    printf("Escriba el valor de b:\t");
    scanf("%d",&b);
    res=(x+y)*(x+y)*(a-b);
    
    printf("El resultado de la operacion es:%d\n",res);
  
  system("PAUSE");	
  return 0;
}
