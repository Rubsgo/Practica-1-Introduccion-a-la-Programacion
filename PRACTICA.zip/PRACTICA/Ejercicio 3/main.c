#include <stdio.h>
#include <stdlib.h>
float const PI=3.14;

int main(int argc, char *argv[])
{
  float r,h,A,V,g; 
  printf("Para obtener el area y volumen de un cono\n"); 
  
  printf("Escriba el valor del radio:\t");
  scanf("%f",&r);
  printf("Escriba el valor de la altura:\t");
  scanf("%f",&h);
  
  g=sqrt((h*h)+(r*r));
  A=(PI*r*g)+(PI*r*r);
  V=(PI*r*r*h)/3;
  
  printf("El area del cono es:%f\n",A);
  printf("El volumen del cono es:%f\n",V);
  
  system("PAUSE");	
  return 0;
}
